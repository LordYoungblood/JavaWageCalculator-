

public class Employee{
    private String name;
    private double payRate;
    private double hoursWorked;

    public Employee(String pName){
        name = pName;
    }

    public String getName(){
        return name;
    }

    public double getPayRate(){
        return payRate;
    }

    public double getHoursWorked(){
        return hoursWorked;
    }

    public boolean setPayRate(double pPayRate){
        if(pPayRate < 0) {
            System.out.println("Invalid payrate. Payrate cannot be negetive.");
            return false;
        }
        if(pPayRate > 100000) {
            System.out.println("Invalid payrate. Payrate is too much.");
            return false;
        }

        payRate = pPayRate;
        return true;
    }

    public boolean setHoursWorked(double pHoursWorked){
        if(pHoursWorked < 0) {
            System.out.println("Invalid hours worked. hours worked cannot be negetive.");
            return false;
        }
        if(pHoursWorked > 65) {
            System.out.println("Invalid hours worked. hours worked cannot be more than 24.");
            return false;
        }

        hoursWorked = pHoursWorked;
        return true;
    }
}

/*
Main.java

matn method{

    Employee emp = new Employee("John Smith");

    System.out.println("New employee's name is: " + emp.getName());

    emp,payrate = -100;
}

*/